<?php
session_start();
include 'db.php';
$id = $_GET['id'];
$sql= "select * from `student_data` where roll_no=$id";
$query = mysqli_query($conn,$sql);
$result = mysqli_fetch_assoc($query);


?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width" initial scale="1">
<link rel="stylesheet" href="bootstrap.min.css">
<script src="bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body>	

<?php require 'nav.php'?>

<!-- form -->

<div class="container">
	
	<div class="row" style="margin-top: 12px">
		<h4 style="text-align: left">Users List</h4>
		<!-- <input type="button" class="btn btn-success" name="add" value="Add Data"> -->
		<a href="display.php">&nbsp&nbsp&nbsp&nbspAdd Data</a>
	</div>
</div>

<div class="container">

	<form action="update.php" method="post" enctype="multipart/form-data">
	<div class="row" style="margin-top: 15px">
		<div class="col-md-4 com-sm-4">
			<label for="fname">Enter Student Full Name</label><br>
			<input type="text" name="full_name" autocomplete="off" class="form-control" value="<?php echo $result['full_name'];?>">
		</div>

		<div class="col-md-4 com-sm-4">
			<label for="email">Email</label><br>
			<input type="email" name="email" placeholder="Enter email" autocomplete="off" class="form-control" value="<?php echo $result['email'];?>">
		</div>

		


		<div class="col-md-4 com-sm-4">
			<label for="cont">Contact no</label><br>
			<input type="text" name="contact" autocomplete="off" class="form-control" value="<?php echo $result['contact'];?>">
		</div>
	</div>


	<div class="row" style="margin-top: 15px">
		<div class="col-md-4 com-sm-4">
			<label for="address">Address</label><br>
			<input type="text" name="address" autocomplete="off" class="form-control" value="<?php echo $result['address'];?>">
		</div>

		<div class="col-md-4 com-sm-4">
			<label for="city">City</label><br>

			<select name="city" id="" class="form-control">
			  <option value="Mumbai" <?php $result['city']=='Mumbai'? print "selected" : "";?>>Mumbai</option>
			  <option value="Thane" <?php $result['city']=='Thane'? print "selected" : "";?>>Thane</option>
			  <option value="Navi Mumbai" <?php $result['city']=='Navi Mumbai'? print "selected" : "";?>>Navi Mumbai</option>
			  <option value="Pune" <?php $result['city']=='Pune'? print "selected" : "";?>>Pune</option>
			</select>	
		</div>

		<div class="col-md-4 com-sm-4">
			<label for="pin">Pincode</label><br>
			<input type="text" name="pincode" autocomplete="off" class="form-control" value="<?php echo $result['pincode'];?>">
		</div>

	</div>

		<div class="row" style="margin-top: 15px">
		    <div class="col-md-4 col-sm-4" style="margin-top: 15px">	
				<laber for="gender">Gender: </label><br>
				<input type="radio" name="gender" value="Male" <?php if($result['gender']=='Male') echo "checked='checked'";?>>&nbsp&nbspMale

				<input type="radio" name="gender" value="Female" <?php if($result['gender']=='Female') echo "checked='checked'";?>>&nbsp&nbspFemale<br>	
				   <!-- <span class="error">* <?php echo $genderErr;?></span><br><br>  -->
		  </div>


		  <div class="col-md-4 col-sm-4">	
		  	 <label for="image">Upload Photo</label><br>
		  	 <img src="http://localhost:8080/Junior_php_assignment/assignment//<?php echo $result['image']; ?>" style="width: 150px;height:100px;">
		  </div>

		  <div class="col-md-4 col-sm-4">	
		  	 <label for="Company">Select Class</label><br>
			
				<select name="class_name" id="" class="form-control">
					<option value="7th" <?php $result['class_name']=='7th'? print "selected" : "";?>>7th</option>
					<option value="8th" <?php $result['class_name']=='8th'? print "selected" : "";?>>8th</option>
					<option value="9th" <?php $result['class_name']=='9th'? print "selected" : "";?>>9th</option>
					<option value="10th" <?php $result['class_name']=='10th'? print "selected" : "";?>>10th</option>
				  
				</select>
		  </div>
	 </div>



	 </div>
	 
	 <input type="submit" class="btn btn-success" name="update" value="update">
	 <input type="hidden" name="id" value="<?php echo $id; ?>">
	 <input type="reset" class="btn btn-success" name="reset" value="Reset">
	 
	</form>
</div>

<div class="container-fluid" style="margin-top: 15px">
<!-- <center><a href="display.php"><strong>View Data</strong></a> -->
</div>
 


</body>
</html>			