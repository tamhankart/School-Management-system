<?php
session_start();
// error_reporting(0);

$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["image"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["image"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } 
  else {
    echo "File is not an image.";
    $uploadOk = 0;
  }
}

// Check if file already exists
if (file_exists($target_file)) {
  echo "Sorry, file already exists.";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
    echo "The file ". htmlspecialchars( basename( $_FILES["image"]["name"])). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}
?>





<?php



include 'db.php';

if(isset($_POST['update'])){

$id = $_POST['id'];
$fname = $_POST['full_name'];
$email = $_POST['email'];
// $password = $_POST['password'];
$contact = $_POST['contact'];
$address = $_POST['address'];
$city = $_POST['city'];
$pincode = $_POST['pincode'];
$gender = $_POST['gender'];
$image = $_FILES['image'];
$class_name = $_POST['class_name'];

$sql="UPDATE `student_data` SET roll_no=$id, full_name = '$fname', email= '$email', contact ='$contact',  address ='$address', city='$city', pincode = '$pincode',gender = '$gender', class_name='$class_name', image='$target_file' WHERE roll_no=$id";


$result = mysqli_query($conn, $sql);

// header('location:display.php');
if($result){
	echo "success";
}
else{
	echo "error";
}
header('location:display.php');
}	
?>