<?php  
 $connect = mysqli_connect("localhost", "root", "", "sms");  
 
 $name=$_POST['name'];
 $class_name=$_POST['class_name'];
 // echo $subject_name;die();
 $passing_marks=$_POST['passing_marks'];
 // print_r($passing_marks) ;die();
 $out_of_marks=$_POST['out_of_marks'];
 for($i=0;$i<count($name);$i++)
 {
  if($name[$i]!="" && $passing_marks[$i]!="" && $out_of_marks[$i]!="")
  {
    $sql= "insert into class (name,class_name,passing_marks,out_of_marks) values('$name[$i]','$class_name','$passing_marks[$i]','$out_of_marks[$i]')";  
   
   // echo $sql;die();

   $result=mysqli_query($connect, $sql);  

   if($result){
     echo "inserted";
   }
   else{
     echo "fail to insert";
   }

  }

 }

 ?> 
   
