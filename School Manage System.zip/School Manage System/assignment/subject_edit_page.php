<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width" initial scale="1">
<link rel="stylesheet" href="bootstrap.min.css">
<script src="bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Welcome </title>
  </head> 
      <body>  
          <?php require 'nav.php'; ?><br>
          <form action="">
           <div class="container">
             <div class="row">
                <div class="col-md-8 col-sm-8">
                  <label for="class">Enter Class Name</label>
                  <select class="form-control" name="search">
                    <option disabled selected>-- Select City --</option>
                    <?php
                        include "db.php";  // Using database connection file here
                        $records = mysqli_query($conn, "SELECT distinct class_name From class");  // Use select query here 

                        while($data = mysqli_fetch_array($records))
                        {
                            echo "<option value='". $data['class_name'] ."'>" .$data['class_name'] ."</option>";  // displaying data in option menu

                        } 
                    ?>  
                  </select>
                  <br><input type="submit" class="btn btn-primary" name="Go" value="Go">
                </div>

             </div>
           </div>
           </form>
           <?php
           if(isset($_POST['search'])){
            $search_value = $_POST['search'];

            $q = "SELECT * from student_data where active = 0 AND class_name LIKE  '%$search_value%'";  

            $query = mysqli_query($conn, $q);

            while ($fetch = mysqli_fetch_array($query)){
  
?>     
      <tr>
        <td><?php echo $fetch['roll_no']; ?></td>
        <td><?php echo $fetch['full_name']; ?></td>
        <td><?php echo $fetch['gender']; ?></td>
        <td><?php echo $fetch['class_name']; ?></td>
        <td><?php echo $fetch['contact']; ?></td>
        <td><?php echo $fetch['sub1']; ?></td>
        <td><?php echo $fetch['sub2']; ?></td>
        <td><?php echo $fetch['sub3']; ?></td>
        <td><?php echo $fetch['sub4']; ?></td>
        <td><?php echo $fetch['sub5']; ?></td>
        <td><?php echo $fetch['sub6']; ?></td>
        
        
        
        <td><a href="soft_delete.php?id=<?php echo $res['roll_no']; ?>"><button class="btn btn-sm btn-danger">Delete</button></a>
        </td>
        <td><a href="edit.php?id=<?php echo $res['roll_no']; ?>"><button class="btn btn-sm btn-success">Edit</button></a>
        </td>

        </tr>
        <?php 
      }

      
      ?>

  </table>  
  

            while ($res= mysqli_fetch_array ($queryd)){
  
?>     
      <tr>
        <td><?php echo $res['roll_no']; ?></td>
        <td><?php echo $res['full_name']; ?></td>
        <td><?php echo $res['gender']; ?></td>
        <td><?php echo $res['class_name']; ?></td>
        <td><?php echo $res['contact']; ?></td>
        <td><?php echo $res['sub1']; ?></td>
        <td><?php echo $res['sub2']; ?></td>
        <td><?php echo $res['sub3']; ?></td>
        <td><?php echo $res['sub4']; ?></td>
        <td><?php echo $res['sub5']; ?></td>
        <td><?php echo $res['sub6']; ?></td>
        
        
        
        <td><a href="soft_delete.php?id=<?php echo $res['roll_no']; ?>"><button class="btn btn-sm btn-danger">Delete</button></a>
        </td>
        <td><a href="edit.php?id=<?php echo $res['roll_no']; ?>"><button class="btn btn-sm btn-success">Edit</button></a>
        </td>

        </tr>
        <?php 
      }

      
      ?>

  </table>  
  

                      
                
      </body>  
 </html>  
 