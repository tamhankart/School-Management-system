
<!DOCTYPE html>
<html>
<head>
	<title></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width" initial scale="1">
<link rel="stylesheet" href="bootstrap.min.css">
<script src="bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body>	

<?php require 'nav.php'?>

<!-- form -->

<div class="container">
	
	<div class="row" style="margin-top: 12px">
		<h4 style="text-align: left">Users List</h4>
		<!-- <input type="button" class="btn btn-success" name="add" value="Add Data"> -->
		<a href="display.php">&nbsp&nbsp&nbsp&nbspAdd Data</a>
	</div>
</div>

<div class="container">

	<form action="add_student.php" method="post" enctype="multipart/form-data">
	<div class="row" style="margin-top: 15px">
		<div class="col-md-4 com-sm-4">
			<label for="fname">Enter Student Full Name</label><br>
			<input type="text" name="full_name" autocomplete="off" class="form-control">
		</div>

		<div class="col-md-4 com-sm-4">
			<label for="email">Email</label><br>
			<input type="email" name="email" placeholder="Enter email" autocomplete="off" class="form-control">
		</div>

		


		<div class="col-md-4 com-sm-4">
			<label for="cont">Contact no</label><br>
			<input type="text" name="contact" autocomplete="off" class="form-control">
		</div>
	</div>


	<div class="row" style="margin-top: 15px">
		<div class="col-md-4 com-sm-4">
			<label for="address">Address</label><br>
			<input type="text" name="address" autocomplete="off" class="form-control">
		</div>

		<div class="col-md-4 com-sm-4">
			<label for="city">City</label><br>

			<select name="city" id="" class="form-control">
			  <option value="Mumbai">Mumbai</option>
			  <option value="Thane">Thane</option>
			  <option value="Navi Mumbai">Navi Mumbai</option>
			  <option value="Pune">Pune</option>
			</select>	
		</div>

		<div class="col-md-4 com-sm-4">
			<label for="pin">Pincode</label><br>
			<input type="text" name="pincode" autocomplete="off" class="form-control">
		</div>

	</div>

		<div class="row" style="margin-top: 15px">
		    <div class="col-md-4 col-sm-4" style="margin-top: 15px">	
				<laber for="gender">Gender: </label><br>
				<input type="radio" value="Male" name="gender">&nbsp&nbspMale
				<input type="radio" value="Female" name="gender">&nbsp&nbspFemale<br>	
				   <!-- <span class="error">* <?php echo $genderErr;?></span><br><br>  -->
		  </div>


		  <div class="col-md-4 col-sm-4">	
		  	 <label for="image">Upload Photo</label><br>
		  	 <input type="file" name="image" >
		  </div>

		  <div class="col-md-4 col-sm-4">	
		  	 <label for="Company">Select Class</label><br>
			
				<select class="form-control" name="class_name">
                    <option disabled selected>-- Select City --</option>
                    <?php
                        include "db.php";  // Using database connection file here
                        $records = mysqli_query($conn, "SELECT distinct class_name From class");  // Use select query here 

                        while($data = mysqli_fetch_array($records))
                        {
                            echo "<option value='". $data['class_name'] ."'>" .$data['class_name'] ."</option>";  // displaying data in option menu

                        } 
                    ?>  
                  </select>
		  </div>
	 </div>
	 <input type="submit" class="btn btn-success" name="submit">
	 <input type="reset" class="btn btn-success" name="reset" value="Reset">
	</form>
</div>

<div class="container-fluid" style="margin-top: 15px">
<!-- <center><a href="display.php"><strong>View Data</strong></a> -->
</div>
 
<div class="container" style="margin-top: 15px">
<a href="student_marks.php"><button class="btn btn-primary">Click Here to Enter Student Marks </button></a>
</div>



</body>
</html>			