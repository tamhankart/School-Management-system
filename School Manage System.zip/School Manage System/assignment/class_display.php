<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width" initial scale="1">
<link rel="stylesheet" href="bootstrap.min.css">
<script src="bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Welcome </title>
  </head>
  <body>
    <?php require 'nav.php'?>
    
<!-- form -->

<div class="container">
	
	<div class="row" style="margin-top: 10px">
		<h4 style="text-align: left">Student List</h4>
		
    <a href="student_form.php" class="btn btn-primary" style="margin-left: 20px">Add Student Data Here</a>
	<a href="student_marks.php" class="btn btn-primary" style="margin-left: 20px">Add Student Marks Here</a></div>
</div>


	<div class="container" style="margin-top: 10px">
<center>
	<form action="display.php" method="POST" style="margin-bottom: : 15px">
<input type="search" name="search" size="80"  class="form-control" placeholder="Search Class Name Here First" value="">
<input type="submit" name="submit" value="search" class="btn btn-success" class="form-control">
	</form>
</center>
	</div>

<br>
		
    		<table class="table table-bordered table-sm">
    		<tr>
			  <th class="th-sm">No</th>
			  <th class="th-sm">Subject Name</th>
			  <th class="th-sm">Class Name</th>
			  <th class="th-sm">Passing Marks</th>
			  <th class="th-sm">Out of Marks(Total)</th>			  
			  <th class="th-sm" colspan="2">Action</th>

			<tr>

<?php

include'db.php';

if(isset($_POST['search'])){
	$search_value=$_POST["search"]; 
 
	$q = "SELECT * from class where active = 0 AND class_name LIKE  '%$search_value%' OR name LIKE  '%$search_value%' ";	
}

else{

$q= "select * from  `class` Where active = 0";
$search_value=" ";
}
// echo $q; die();

$queryd = mysqli_query($conn,$q);

// $queryd=mysqli_query($conn,$q);

while ($res= mysqli_fetch_array ($queryd)){
	
?>     
		 	<tr>
				<td><?php echo $res['id']; ?></td>
				<td><?php echo $res['name']; ?></td>
				<td><?php echo $res['class_name']; ?></td>
				<td><?php echo $res['passing_marks']; ?></td>
				<td><?php echo $res['out_of_marks']; ?></td>
				<td><a href="delete_class_detail.php?id=<?php echo $res['id']; ?>"><button class="btn btn-sm btn-danger">Delete</button></a>
				</td>
				<td><a href="edit_class_detail.php"><button class="btn btn-sm btn-success">Edit</button></a>

				</tr>
				<?php 
			}

			
			?>

	</table>	
	
			

		
	
</body>
</html>				