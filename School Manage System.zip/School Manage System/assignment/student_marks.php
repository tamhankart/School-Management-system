<?php
include'db.php';

// session_start();

// if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
//     header("location: login.php");
//     exit;
// }

?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width" initial scale="1">
<link rel="stylesheet" href="bootstrap.min.css">
<script src="bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Welcome </title>
  </head>
  <body>
    <?php require 'nav.php'?>
    
<!-- form -->

<div class="container">
	
	<div class="row" style="margin-top: 10px">
		<h4 style="text-align: left">Student List</h4>
		
    <a href="student_form.php" class="btn btn-primary" style="margin-left: 20px">Add Student Data</a>
    <a href="display.php" class="btn btn-primary" style="margin-left: 20px">View Student Data with Status</a>
	</div>
</div>


	<div class="container" style="margin-top: 10px">
<center>
	<form action="" method="POST" style="margin-bottom: : 15px">
<input type="search" name="search" size="80" placeholder="Search for Class Name " value="" class="form-control">
<input type="submit" name="submit" value="search" class="btn btn-success">
	</form>
</center>
	</div>

<br>
		
    		<table class="table table-bordered table-sm">
    		<tr>
			  <th class="th-sm">Roll No</th>
			  <th class="th-sm">Full Name</th>
			  <th class="th-sm">Gender</th>
			  <th class="th-sm">Class Name</th>
			  <th class="th-sm">Contact</th>
			  <th class="th-sm" colspan="7" style="text-align: center;">Subject List</th>
			  <th class="th-sm" colspan="2">Action</th>

			<tr>
				<tr>
			  <th class="th-sm" colspan="5"></th>
			  <?php

			  if(isset($_POST['search'])){
	$search_value=$_POST["search"]; 
 
	$sub = "SELECT * from student_data where active = 0 AND class_name LIKE  '%$search_value%' OR full_name LIKE  '%$search_value%'";	
}

			  $sub = "select distinct name from class where class_name LIKE '%ssc%'";

			  $subquery = mysqli_query($conn,$sub);

			  while ($subname= mysqli_fetch_array($subquery)) {
			  	# code...
			  
$count=1;
			  ?>
			  
			 <th><?php echo $subname['name']; $count++; 


			 if($count>6)
			 {
			 	echo "Only Maximum 6 Subjects allowed.";
			 }
			 ?> </th>
			 
			  
			  <?php 
			  }

			  ?>
			  <th></th>
			  <!-- <th class="th-sm">comp</th>	
			  <th class="th-sm">Images</th>
			  <th class="th-sm">City</th>
			  <th class="th-sm">Pin</th> -->
			  <th class="th-sm" colspan="2"></th>

			<tr>

<?php


if(isset($_POST['search'])){
	$search_value=$_POST["search"]; 
 
	$q = "SELECT * from student_data where active = 0 AND class_name LIKE  '%$search_value%'";	
}

else{

$q= "select * from  `student_data` Where active = 0 and class_name='ssc'";
$search_value=" ";
}
// echo $q; die();

$queryd = mysqli_query($conn,$q);

// $queryd=mysqli_query($conn,$q);

while ($res= mysqli_fetch_array ($queryd)){
	
?>     
		 	<tr>
		 		
				<td><?php echo $res['roll_no']; ?></td>
				<td><?php echo $res['full_name']; ?></td>
				<td><?php echo $res['gender']; ?></td>
				<td><?php echo $res['class_name']; ?></td>
				<td><?php echo $res['contact']; ?></td>
			
				<div class="container">
					<form action="insert_student_marks.php" method="post" enctype="multipart/form-data">
						<div class="row">
						
							<td><input type="text" name="sub1" size="2"></td>
							<td><input type="text" name="sub2" size="2"></td>
							<td><input type="text" name="sub3" size="2"></td>
							<td><input type="text" name="sub4" size="2"></td>
							<td><input type="text" name="sub5" size="2"></td>
							<td><input type="text" name="sub6" size="2"></td>
							<input type="hidden" name="id" value="<?php echo $res['roll_no']; ?>">
							<td><input type="submit" class="btn btn-primary" name="submit" value="Submit"></td>
						</div>
					</div>
				</div>

				</td>
			</form>
				<td><a href="soft_delete.php?id=<?php echo $res['roll_no']; ?>"><button class="btn btn-sm btn-danger">Delete</button></a>
				</td>
				<td><a href="edit.php?id=<?php echo $res['roll_no']; ?>"><button class="btn btn-sm btn-success">Edit</button></a>
				</td>
				
			
				</tr>
				<?php 
			}

			
			?>

	</table>	
	
			
	
</body>
</html>				