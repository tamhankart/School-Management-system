<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width" initial scale="1">
<link rel="stylesheet" href="bootstrap.min.css">
<script src="bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Welcome </title>
  </head> 
      <body>  
          <?php require 'nav.php'; ?>
           <div class="container">  
                <br />  
                <br />  
                
                
               
                <div class="form-group">  
                     <form name="add_name" id="add_name">
                        <div class="row">
                         <div class="col-md-12 col-sm-12">
                              <label for="sname">Enter Class Name</label>
                              <input type="text" name="class_name" class="form-control name_list"><br>

                    </div>
               </div>  
               <h4 class="text-primary">*Enter only 6 subjects for the class</h4>
                          <div class="table-responsive">  

                               <table class="table table-bordered" id="dynamic_field">  
                                    <tr>  
                                         <td><input type="text" name="name[]" placeholder="Enter Subject Name" class="form-control name_list" /></td>  
                                         <td><input type="text" name="passing_marks[]" placeholder="Enter passing marks" class="form-control name_list" /></td>
                                         <td><input type="text" name="out_of_marks[]" placeholder="Enter out_of_marks" class="form-control name_list" /></td>
                                         <td><button type="button" name="add" id="add" class="btn btn-success">Add More</button></td>  
                                    </tr>  
                               </table>  
                               <input type="button" name="submit" id="submit" class="btn btn-info" value="Submit" />  
                               <input type="button" name="edit" id="submit" class="btn btn-info" value="Edit Subjects" />
                          </div>  
                     </form>  
                </div>  <br>
           <a href="class_display.php"><button class="btn btn-dark" name="" >---Click Here to See Class Details ---</button></a>
           
      <a href="student_marks.php" class="btn btn-dark" style="margin-left: 20px">Add Student Marks Here</a>
      <a href="student_form.php" class="btn btn-dark" style="margin-left: 20px">Add Student Data Here</a>
      <a href="display.php" class="btn btn-dark" style="margin-left: 20px">Student Details with Status</a>
      </body>  
 </html>  
 <script>  
 $(document).ready(function(){  
      var i=1;  
      $('#add').click(function(){  
           i++;  
           $('#dynamic_field').append('<tr id="row'+i+'"><td><input type="text" name="name[]" placeholder="Enter your Name" class="form-control name_list" /></td><td><input type="text" name="passing_marks[]" placeholder="Enter passing marks" class="form-control name_list" /></td><td><input type="text" name="out_of_marks[]" placeholder="Enter out_of_marks" class="form-control name_list" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
      });  
      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
      });  
      $('#submit').click(function(){            
           $.ajax({  
                url:"name.php",  
                method:"POST",  
                data:$('#add_name').serialize(),  
                success:function(data)  
                {  
                     alert(data);  
                     $('#add_name')[0].reset();  
                }  
           });  
      });  
 });  
 </script>
   