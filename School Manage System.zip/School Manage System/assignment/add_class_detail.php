<?php

include 'db.php';
// error_reporting(0);


$class_name = $_POST['class_name'];
// echo $class_name;die();
$passing_marks = $_POST['passing_marks'];
// echo $passing_marks;die();
$out_of_marks = $_POST['out_of_marks'];
// echo $out_of_marks;die();



 $sql= "INSERT INTO `class` (`passing_marks`, `out_of_marks`) VALUES ('$passing_marks','$out_of_marks');";

 $sql= "INSERT INTO `student_data` (`passing_marks`, `out_of_marks`) VALUES ('$passing_marks','$out_of_marks');";

    

$result=mysqli_query($conn,$sql);



?>







