<?php

include 'db.php';

if(isset($_POST['update'])){

$id = $_POST['id'];
$fname = $_POST['full_name'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$address = $_POST['address'];
$city = $_POST['city'];
$pincode = $_POST['pincode'];
$gender = $_POST['gender'];
$image = $_FILES['image'];
$class_name = $_POST['class_name'];

$sql="UPDATE `student_data` SET roll_no=$id, full_name = '$fname', email= '$email', contact ='$contact',  address ='$address', city='$city', pincode = '$pincode',gender = '$gender', class_name='$class_name', image='$target_file' WHERE roll_no=$id";
// echo $sql;die();



$result = mysqli_query($conn, $sql);


if($result){
	echo "success";
}
else{
	echo "error";
}
echo "<script>
alert('Successfully Updated');
window.location.href='dispaly.php';
</script>";

}	
?>