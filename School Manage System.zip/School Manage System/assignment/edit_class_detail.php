<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width" initial scale="1">
<link rel="stylesheet" href="bootstrap.min.css">
<script src="bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Welcome </title>
  </head> 
      <body>  
          <?php require 'nav.php'; ?>
           <div class="container">  
                <br />  
                <br />  
                
                
               
                <div class="form-group">  
                     <form action="" method="POST">
                        <div class="row">
                         <div class="col-md-12 col-sm-12">
                              <label for="sname"> Class Name</label>
                              <select class="form-control" name="search">
                    <option disabled selected>-- Select City --</option>
                    <?php
                        include "db.php";  // Using database connection file here
                        $records = mysqli_query($conn, "SELECT distinct class_name From class");  // Use select query here 

                        while($data = mysqli_fetch_array($records))
                        {
                            echo "<option value='". $data['class_name'] ."'>" .$data['class_name'] ."</option>";  // displaying data in option menu

                        } 
                    ?>  
                  </select><br>

                   <input type="submit" name="submit" value="---Enter---" class="btn btn-success"><br>
                 </form>
                  <?php

include 'db.php';

if(isset($_POST['search'])){
  $search_value=$_POST["search"]; 
  // echo $search_value;die();

$sql_class = "SELECT * from class where active = 0 AND class_name LIKE  '%$search_value%'";  
}
else{
  $sql_class = "select * from class where active=0";
}


$query_class = mysqli_query($conn,$sql_class);
?>                       
                              <br>
                    
                    </div>
               </div> 
               <!-- <h4 class="text-primary">*Enter only 6 subjects for the class</h4> -->
                          <div class="table-responsive">  
                            
                            <?php 
                                while($result_class = mysqli_fetch_array($query_class)){


                            ?>

                               <table class="table table-bordered" id="dynamic_field">  
                                <form action="update_class.php" method="POST">
                                    <tr>
                                      <td>Subject Name</td>
                                      <td>Passing Marks</td>
                                      <td>Out of Marks</td>

                                    </tr>
                                    <tr>  
                                         <td>

                                          <input type="text" name="name[]" placeholder="Enter Subject Name" class="form-control name_list" value="<?php echo $result_class['name']; ?>" /></td>  
                                         <td><input type="text" name="passing_marks[]" placeholder="Enter passing marks" class="form-control name_list" value="<?php echo $result_class['passing_marks']; ?>"/></td>
                                         <td><input type="text" name="out_of_marks[]" placeholder="Enter out_of_marks" class="form-control name_list" value="<?php echo $result_class['out_of_marks']; ?>"/></td>
                                         
                                    </tr>  
                                  <?php } ?>
                                    
                               </table>  

                               <?php 
                               $sql_class_id = "select * from class where active=0";
                               $query_class_id = mysqli_query($conn,$sql_class);
                               $id_fetch = mysqli_fetch_array($query_class_id);
                               ?>
                              <input type="submit" class="btn btn-success" name="update" value="update">

                               <input type="hidden" name="id" value="<?php echo $id_fetch['name']; ?>">
                               
                          </div>  
                     </form>  
                </div>  
           
      </body>  
 </html>  
 
   