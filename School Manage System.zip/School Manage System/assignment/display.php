<?php

// session_start();

// if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
//     header("location: login.php");
//     exit;
// }

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width" initial scale="1">
<link rel="stylesheet" href="bootstrap.min.css">
<script src="bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Welcome </title>
  </head>
  <body>
    <?php require 'nav.php'?>
    
<!-- form -->

<div class="container">
	
	<div class="row" style="margin-top: 10px">
		<h4 style="text-align: left">Student List</h4>
		
    <a href="student_form.php" class="btn btn-primary" style="margin-left: 20px">Add Student Data Here</a>
	<a href="student_marks.php" class="btn btn-primary" style="margin-left: 20px">Add Student Marks Here</a></div>
</div>


	<div class="container" style="margin-top: 10px">
<center>
	<form action="display.php" method="POST" style="margin-bottom: : 15px">
<input type="search" name="search" size="80"  class="form-control" placeholder="Search Class Name Here First" value="">
<input type="submit" name="submit" value="search" class="btn btn-success" class="form-control">
	</form>
</center>
	</div>

<br>
		
    		<table class="table table-bordered table-sm">
    		<tr>
			  <th class="th-sm">Roll No</th>
			  <th class="th-sm">Full Name</th>
			  <th class="th-sm">Email</th>
			  <th class="th-sm">Status</th>
			  <th class="th-sm">Contact</th>
			  <th class="th-sm">Address</th>
			  <th class="th-sm">City</th>
			  <th class="th-sm">Pincode</th>
			  <th class="th-sm">Gender</th>
			  <th class="th-sm">Class Name</th>
			  <th class="th-sm">Photo</th>
			  <th class="th-sm" colspan="2">Action</th>

			<tr>

<?php

include'db.php';

if(isset($_POST['search'])){
	$search_value=$_POST["search"]; 
 
	$q = "SELECT * from student_data where active = 0 AND class_name LIKE  '%$search_value%'";	
}

else{

$q= "select * from  `student_data` Where active = 0";
$search_value=" ";
}
// echo $q; die();

$queryd = mysqli_query($conn,$q);

// $queryd=mysqli_query($conn,$q);

while ($res= mysqli_fetch_array ($queryd)){
	
?>     
		 	<tr>
				<td><?php echo $res['roll_no']; ?></td>
				<td><?php echo $res['full_name']; ?></td>
				<td><?php echo $res['email']; ?></td>
				<td style="word-wrap: break-word;">
					<?php if($res['percentage']>=50){ 
						echo "<strong>Promoted for Next Class<strong>";
					}
						else{
							echo "<strong>Not Promoted to Next Class</strong>";
						}


				; ?></td>
				<td><?php echo $res['contact']; ?></td>
				<td><?php echo $res['address']; ?></td>
				<td><?php echo $res['city']; ?></td>
				<td><?php echo $res['pincode']; ?></td>
				<td><?php echo $res['gender']; ?></td>
				<td><?php echo $res['class_name']; ?></td>
				<td><img src="http://localhost:8080/Project_on_files/Crud_op/<?php echo $res['image']; ?>" style="width: 40px;height:40px;"></td>
				
				<td><a href="soft_delete.php?id=<?php echo $res['roll_no']; ?>"><button class="btn btn-sm btn-danger">Delete</button></a>
				</td>
				<td><a href="edit.php?id=<?php echo $res['roll_no']; ?>"><button class="btn btn-sm btn-success">Edit</button></a>
				</td>

				</tr>
				<?php 
			}

			
			?>

	</table>	
	
			

		
	
</body>
</html>				