<?php 
//Delete class details query
include'db.php';

$id = $_GET['id'];

// $q = "UPDATE `users` SET active = 1 WHERE id = $id";

$q="UPDATE `class` SET active = 1 WHERE id=$id";

$res = mysqli_query($conn, $q);


echo "<script>
alert('Successfully Deleted');
window.location.href='class_display.php';
</script>";
?>


