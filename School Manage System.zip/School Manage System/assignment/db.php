<?php
//Database connection
$servername = "localhost";
$username = "root";
$password = "";	
$database = "sms";

$conn = mysqli_connect($servername,$username,$password,$database); 

if(!$conn){
	echo "failed to connect with database".mysqli_connect_error();

}
else{
	
}


?>