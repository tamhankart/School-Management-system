<?php 
session_start();
include'db.php';

$id = $_GET['id'];

// $q = "UPDATE `users` SET active = 1 WHERE id = $id";

$q="UPDATE `student_data` SET active = 1 WHERE roll_no=$id";

$res = mysqli_query($conn, $q);

echo "<script>
alert('Successfully Updated');
window.location.href='display.php';
</script>";

?>


