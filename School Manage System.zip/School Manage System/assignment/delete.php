<?php 

include'db.php';

$id = $_GET['id'];

$q = "DELETE FROM `student_data` WHERE roll_no = $id";

$res=mysqli_query($conn, $q);



echo "<script>
alert('Successfully Deleted');
window.location.href='display.php';
</script>";

if($res){
	echo "Data Deleted";
}

?>

