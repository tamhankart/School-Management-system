<?php

include 'db.php';
// error_reporting(0);
//Connecting to the Database


$id= $_POST['id'];
// echo $id;die();
$sub1 = $_POST['sub1'];
// echo $sub1;die();
$sub2 = $_POST['sub2'];
$sub3 = $_POST['sub3'];
$sub4 = $_POST['sub4'];
$sub5 = $_POST['sub5'];
$sub6 = $_POST['sub6'];
$total = $sub1+$sub2+$sub3+$sub4+$sub5+$sub6;
$out_of_marks=600;
$percentage=$total/$out_of_marks*100;

$sql= "UPDATE `student_data` SET sub1='$sub1', sub2='$sub2', sub3='$sub3', sub4='$sub4', sub5='$sub5',sub6='$sub6', total='$total', out_of_marks=600, percentage='$percentage' WHERE roll_no='$id'";



    // $sql="UPDATE `student_data` SET roll_no=$id, full_name = '$fname', email= '$email', contact ='$contact',  address ='$address', city='$city', pincode = '$pincode',gender = '$gender', class_name='$class_name', image='$target_file' WHERE roll_no=$id";

$result=mysqli_query($conn,$sql);
if($result)
{
	
	echo "<script>
alert('Successfully added');
window.location.href='student_marks.php';
</script>";
    
    
  // header('Junior_php_assignment/assignment/student_marks.php');
}
else
{
	echo "Error in inserting data";
}


?>
