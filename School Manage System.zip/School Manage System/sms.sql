-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2021 at 10:44 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` int(24) NOT NULL,
  `name` varchar(255) NOT NULL,
  `class_name` varchar(32) NOT NULL,
  `passing_marks` int(24) NOT NULL,
  `out_of_marks` int(24) NOT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `name`, `class_name`, `passing_marks`, `out_of_marks`, `active`) VALUES
(52, 'sub1', 'ssc', 23, 23, 1),
(53, 'sub2', 'ssc', 34, 43, 0),
(54, 'sub3', 'ssc', 34, 54, 0),
(55, 'sub4', 'ssc', 34, 54, 0),
(56, 'sub5', 'ssc', 34, 50, 0),
(57, 'sub6', 'ssc', 34, 67, 0),
(58, 'marathi', '7th', 50, 100, 0),
(59, 'Eng', '7th', 50, 100, 0),
(60, 'History', '7th', 50, 100, 0),
(61, 'maths', '7th', 50, 100, 0),
(62, 'Sci', '7th', 50, 100, 0),
(63, 'Geo', '7th', 50, 50, 0),
(64, 'fsd', 'fsdf', 234, 4324, 1),
(65, 'dfs', 'fsdf', 23, 43, 0),
(66, 'fsdf', 'fsdf', 23, 23, 0),
(67, '234', 'fsdf', 23, 423, 0),
(68, 'fsdf', 'fsdf', 23, 32, 0),
(69, 'fsd', 'fsdf', 34, 43, 0),
(70, 'er', 'era', 23, 23, 0),
(71, 'era', 'era', 23, 23, 0),
(72, 'mar', '8th', 23, 23, 0),
(73, 'eng', '8th', 32, 32, 0),
(74, 'mar', '9th', 20, 100, 0),
(75, 'eng', '9th', 23, 100, 0),
(76, 'History', '9th', 23, 23, 0),
(77, 'math', '9th', 34, 54, 0),
(78, '23', 'fsdf', 434, 434, 0),
(79, 'er', 'fsdf', 0, 0, 0),
(80, '23', 'dasd', 43, 432, 0),
(81, '432', 'dasd', 432, 42, 0),
(82, 'fsd', 'fsd', 0, 0, 0),
(83, 'fsd', 'fsd', 0, 0, 0),
(84, 'fsdf', 'fsdf', 23, 23, 0),
(85, '2f', 'fsdf', 23, 23, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_data`
--

CREATE TABLE `student_data` (
  `roll_no` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(32) NOT NULL,
  `contact` int(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(32) NOT NULL,
  `pincode` int(32) NOT NULL,
  `gender` varchar(12) NOT NULL,
  `image` varchar(255) NOT NULL,
  `class_name` varchar(32) NOT NULL,
  `sub1` int(10) NOT NULL,
  `sub2` int(10) NOT NULL,
  `sub3` int(10) NOT NULL,
  `sub4` int(10) NOT NULL,
  `sub5` int(10) NOT NULL,
  `sub6` int(10) NOT NULL,
  `total` int(10) NOT NULL,
  `out_of_marks` int(10) NOT NULL,
  `percentage` int(10) NOT NULL,
  `status` varchar(32) NOT NULL,
  `active` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_data`
--

INSERT INTO `student_data` (`roll_no`, `full_name`, `email`, `contact`, `address`, `city`, `pincode`, `gender`, `image`, `class_name`, `sub1`, `sub2`, `sub3`, `sub4`, `sub5`, `sub6`, `total`, `out_of_marks`, `percentage`, `status`, `active`) VALUES
(33, 'ssc student', 'ssc@gmail.com', 123, '123', 'Thane', 234, 'Male', 'uploads/', 'ssc', 34, 32, 43, 43, 45, 66, 263, 600, 44, '', 0),
(48, 'sagar', '', 0, '', 'Mumbai', 0, 'Male', 'uploads/', 'ssc', 23, 43, 43, 53, 43, 43, 248, 600, 41, '', 0),
(49, 'amit', '', 0, '', 'Mumbai', 0, 'Male', 'uploads/', 'ssc', 34, 43, 43, 53, 43, 43, 259, 600, 43, '', 0),
(50, 'samit', '', 0, '', 'Mumbai', 0, 'Male', 'uploads/', 'ssc', 34, 43, 32, 53, 43, 43, 248, 600, 41, '', 0),
(51, 'sumit3', '', 0, '', 'Mumbai', 0, 'Male', 'uploads/', 'ssc', 34, 43, 43, 53, 43, 43, 259, 600, 43, '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_data`
--
ALTER TABLE `student_data`
  ADD PRIMARY KEY (`roll_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(24) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `student_data`
--
ALTER TABLE `student_data`
  MODIFY `roll_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
